import os
import shutil

def remove_vscode_folder(start_path="."):
    for root, dirs, files in os.walk(start_path):
        if ".vscode" in dirs:
            vscode_path = os.path.join(root, ".vscode")
            print(f"Removing folder: {vscode_path}")
            shutil.rmtree(vscode_path)
            print("✅ .vscode folder removed.")
            return
    print("ℹ️ No .vscode folder found.")

# 🔧 Run this from your project root folder
if __name__ == "__main__":
    remove_vscode_folder(".")
